#!/bin/bash
# 个人优化
# default
# Vim 终极美化配置（支持 Nerd Fonts + 插件）

echo vim is ok
