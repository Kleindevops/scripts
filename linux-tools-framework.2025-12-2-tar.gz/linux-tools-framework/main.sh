#!/bin/bash
# main.sh 极简版：只负责框架核心 + 调用系统信息

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 调用独立系统信息脚本（一行搞定）
"$DIR/SysInfo/show.sh"

# 下面是你原来的全部框架逻辑（完全不动，只删掉了重复的显示部分）
clear

# 动态生成系统目录
if [[ -f /etc/os-release ]]; then
    source /etc/os-release
    SYS_NAME=$(echo "$NAME" | sed 's/"//g')
    SYS_VER="$VERSION_ID"
    SYS_DIR="${SYS_NAME}_${SYS_VER}"
else
    echo "无法识别系统"; exit 1
fi

FULL_DIR="$DIR/$SYS_DIR"
rm -rf "$FULL_DIR" 2>/dev/null
mkdir -p "$FULL_DIR"

[[ -z "$(ls -A "$DIR/Template"/*.sh 2>/dev/null)" ]] && { echo "Template 为空"; exit 1; }

shopt -s nullglob
for f in "$DIR"/Template/*.sh; do
    category=$(sed -n '2p' "$f" | sed 's/^ *# *//; s/ *$//')
    [[ -z "$category" ]] && category="未分类"
    tag=$(sed -n '3p' "$f" | sed 's/^ *# *//; s/ *$//' | xargs)
    [[ "$tag" == "default" || "$tag" == "$SYS_DIR" ]] || continue
    mkdir -p "$FULL_DIR/$category"
    cp -f "$f" "$FULL_DIR/$category/"
done
shopt -u nullglob

[[ -z "$(find "$FULL_DIR" -mindepth 2 -name '*.sh' 2>/dev/null)" ]] && {
    clear; echo "暂无可用脚本（第三行写 default 或 $SYS_DIR）"; sleep 3; }

while :; do
    clear
    echo "============== BobbyOps 2025 =============="
    # 用 show.sh 的完整信息替换原来的单行提示
    "$DIR/SysInfo/show.sh"
    echo "===================================================="
    mapfile -t cats < <(find "$FULL_DIR" -mindepth 1 -maxdepth 1 -type d | sort)
    [[ ${#cats[@]} -eq 0 ]] && { echo "暂无分类"; sleep 3; continue; }
    for i in "${!cats[@]}"; do printf " %2d. %s\n" $((i+1)) "$(basename "${cats[i]}")"; done
    echo "===================================================="
    read -p "请选择（q清理退出）: " c

    [[ "$c" == "q" || "$c" == "Q" ]] && { rm -rf "$FULL_DIR"; clear; echo "已彻底清理干净！"; exit 0; }

    [[ $c -ge 1 && $c -le ${#cats[@]} ]] || continue
    d="${cats[$((c-1))]}"

    while :; do
        clear
        echo "========== $(basename "$d") =========="
        mapfile -t s < <(ls "$d"/*.sh 2>/dev/null | sort)
        [[ ${#s[@]} -eq 0 ]] && break
        for i in "${!s[@]}"; do
            name=$(basename "${s[i]}" .sh)
            desc=$(sed -n '4p' "${s[i]}" 2>/dev/null | sed 's/^# *//')
            [[ -z "$desc" ]] && desc="$name"
            printf " %2d. %s\n" $((i+1)) "$desc"
        done
        echo "===================================="
        read -p "选择脚本（q返回）: " n
        [[ "$n" == "q" || "$n" == "Q" ]] && break
        [[ $n -ge 1 && $n -le ${#s[@]} ]] || continue
        clear
        bash "${s[$((n-1))]}"
    done
done
